from __future__ import annotations
import os, sqlite3, secrets, hashlib, hmac, time, json, asyncio
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field

DB_PATH = os.getenv("RUSTALK_DB", "rustalk.sqlite3")
SECRET = os.getenv("RUSTALK_SECRET", "CHANGE-ME-before-deployment-please-32-chars")
TOKEN_TTL = 60 * 60 * 24 * 14

app = FastAPI(title="RusTalk API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False,
                   allow_methods=["*"], allow_headers=["*"])
bearer = HTTPBearer(auto_error=False)
connections: dict[int, set[WebSocket]] = {}
connections_lock = asyncio.Lock()

def connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE NOT NULL,
          display_name TEXT NOT NULL,
          password_hash TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions(
          token_hash TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          expires_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chats(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS chat_members(
          chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          PRIMARY KEY(chat_id,user_id)
        );
        CREATE TABLE IF NOT EXISTS messages(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          chat_id INTEGER NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
          sender_id INTEGER NOT NULL REFERENCES users(id),
          text TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id,id);
        """)
init_db()

class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=24, pattern=r"^[a-zA-Z0-9_]+$")
    password: str = Field(min_length=8, max_length=128)
    display_name: Optional[str] = Field(default=None, min_length=1, max_length=48)

class NewChat(BaseModel):
    username: str = Field(min_length=3, max_length=24)

class NewMessage(BaseModel):
    text: str = Field(min_length=1, max_length=4000)

def password_hash(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return salt.hex() + "$" + digest.hex()

def password_ok(password: str, stored: str) -> bool:
    try:
        salt_hex, digest_hex = stored.split("$", 1)
        candidate = password_hash(password, bytes.fromhex(salt_hex)).split("$", 1)[1]
        return hmac.compare_digest(candidate, digest_hex)
    except (ValueError, TypeError):
        return False

def token_digest(token: str) -> str:
    return hashlib.sha256((SECRET + token).encode()).hexdigest()

def issue_token(user_id: int) -> str:
    token = secrets.token_urlsafe(36)
    with connect() as db:
        db.execute("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)",
                   (token_digest(token), user_id, int(time.time()) + TOKEN_TTL))
    return token

def user_for_token(token: str):
    with connect() as db:
        row = db.execute("""SELECT u.id,u.username,u.display_name FROM sessions s
          JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?""",
          (token_digest(token), int(time.time()))).fetchone()
    return dict(row) if row else None

def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds:
        raise HTTPException(401, "Требуется авторизация")
    user = user_for_token(creds.credentials)
    if not user:
        raise HTTPException(401, "Сессия истекла или токен недействителен")
    return user

def require_member(db, chat_id: int, user_id: int):
    row = db.execute("SELECT 1 FROM chat_members WHERE chat_id=? AND user_id=?",
                     (chat_id, user_id)).fetchone()
    if not row:
        raise HTTPException(404, "Диалог не найден")

@app.get("/health")
def health():
    return {"status": "ok", "service": "rustalk-api"}

@app.post("/auth/register")
def register(body: Credentials):
    username = body.username.lower()
    display_name = (body.display_name or body.username).strip()
    if not display_name:
        raise HTTPException(422, "Укажите имя")
    try:
        with connect() as db:
            cur = db.execute("INSERT INTO users(username,display_name,password_hash,created_at) VALUES(?,?,?,?)",
                (username, display_name, password_hash(body.password), int(time.time())))
            uid = cur.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Это имя пользователя уже занято")
    return {"token": issue_token(uid), "user": {"id": uid, "username": username, "display_name": display_name}}

@app.post("/auth/login")
def login(body: Credentials):
    with connect() as db:
        row = db.execute("SELECT * FROM users WHERE username=?", (body.username.lower(),)).fetchone()
    if not row or not password_ok(body.password, row["password_hash"]):
        raise HTTPException(401, "Неверное имя пользователя или пароль")
    return {"token": issue_token(row["id"]), "user": {
        "id": row["id"], "username": row["username"], "display_name": row["display_name"]}}

@app.get("/me")
def me(user=Depends(current_user)):
    return user

@app.get("/users/search")
def search_users(q: str, user=Depends(current_user)):
    q = q.strip().lower()
    if len(q) < 2:
        return []
    with connect() as db:
        rows = db.execute("""SELECT id,username,display_name FROM users
          WHERE username LIKE ? AND id<>? ORDER BY username LIMIT 20""", (f"%{q}%", user["id"])).fetchall()
    return [dict(r) for r in rows]

@app.post("/chats")
def create_chat(body: NewChat, user=Depends(current_user)):
    with connect() as db:
        other = db.execute("SELECT id FROM users WHERE username=?", (body.username.lower(),)).fetchone()
        if not other:
            raise HTTPException(404, "Пользователь не найден")
        if other["id"] == user["id"]:
            raise HTTPException(400, "Нельзя создать диалог с самим собой")
        existing = db.execute("""SELECT c.id FROM chats c
          JOIN chat_members a ON a.chat_id=c.id AND a.user_id=?
          JOIN chat_members b ON b.chat_id=c.id AND b.user_id=?
          WHERE (SELECT COUNT(*) FROM chat_members cm WHERE cm.chat_id=c.id)=2 LIMIT 1""",
          (user["id"], other["id"])).fetchone()
        if existing:
            return {"id": existing["id"]}
        cur = db.execute("INSERT INTO chats(created_at) VALUES(?)", (int(time.time()),))
        chat_id = cur.lastrowid
        db.executemany("INSERT INTO chat_members(chat_id,user_id) VALUES(?,?)",
                       [(chat_id, user["id"]), (chat_id, other["id"])])
    return {"id": chat_id}

@app.get("/chats")
def list_chats(user=Depends(current_user)):
    with connect() as db:
        rows = db.execute("""
          SELECT c.id,
            (SELECT u.username FROM chat_members cm JOIN users u ON u.id=cm.user_id
             WHERE cm.chat_id=c.id AND u.id<>? LIMIT 1) AS username,
            (SELECT u.display_name FROM chat_members cm JOIN users u ON u.id=cm.user_id
             WHERE cm.chat_id=c.id AND u.id<>? LIMIT 1) AS display_name,
            (SELECT m.text FROM messages m WHERE m.chat_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message,
            (SELECT m.created_at FROM messages m WHERE m.chat_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_at
          FROM chats c JOIN chat_members mine ON mine.chat_id=c.id AND mine.user_id=?
          ORDER BY COALESCE(last_at,c.created_at) DESC""", (user["id"], user["id"], user["id"])).fetchall()
    return [dict(r) for r in rows]

@app.get("/chats/{chat_id}/messages")
def list_messages(chat_id: int, before_id: Optional[int] = None, limit: int = 50, user=Depends(current_user)):
    limit = max(1, min(limit, 100))
    with connect() as db:
        require_member(db, chat_id, user["id"])
        if before_id:
            rows = db.execute("""SELECT m.id,m.chat_id,m.sender_id,m.text,m.created_at,u.username
              FROM messages m JOIN users u ON u.id=m.sender_id
              WHERE m.chat_id=? AND m.id<? ORDER BY m.id DESC LIMIT ?""",
              (chat_id, before_id, limit)).fetchall()
        else:
            rows = db.execute("""SELECT m.id,m.chat_id,m.sender_id,m.text,m.created_at,u.username
              FROM messages m JOIN users u ON u.id=m.sender_id
              WHERE m.chat_id=? ORDER BY m.id DESC LIMIT ?""", (chat_id, limit)).fetchall()
    return [dict(r) for r in reversed(rows)]

@app.post("/chats/{chat_id}/messages")
async def send_message(chat_id: int, body: NewMessage, user=Depends(current_user)):
    msg_text = body.text.strip()
    if not msg_text:
        raise HTTPException(422, "Пустое сообщение")
    with connect() as db:
        require_member(db, chat_id, user["id"])
        cur = db.execute("INSERT INTO messages(chat_id,sender_id,text,created_at) VALUES(?,?,?,?)",
                         (chat_id, user["id"], msg_text, int(time.time())))
        message = {"id": cur.lastrowid, "chat_id": chat_id, "sender_id": user["id"],
                   "username": user["username"], "text": msg_text, "created_at": int(time.time())}
        recipients = [r["user_id"] for r in db.execute("SELECT user_id FROM chat_members WHERE chat_id=?", (chat_id,))]
    await broadcast(recipients, {"type": "message", "message": message})
    return message

async def broadcast(user_ids, payload):
    async with connections_lock:
        targets = [(uid, ws) for uid in user_ids for ws in list(connections.get(uid, set()))]
    for uid, ws in targets:
        try:
            await ws.send_text(json.dumps(payload, ensure_ascii=False))
        except Exception:
            async with connections_lock:
                connections.get(uid, set()).discard(ws)

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, token: str):
    user = user_for_token(token)
    if not user:
        await ws.close(code=4401)
        return
    await ws.accept()
    async with connections_lock:
        connections.setdefault(user["id"], set()).add(ws)
    try:
        while True:
            # Client can send ping frames as text; server doesn't execute client commands.
            await ws.receive_text()
            await ws.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        pass
    finally:
        async with connections_lock:
            connections.get(user["id"], set()).discard(ws)
