# RusTalk — стартовый проект

RusTalk — независимый мессенджер-прототип для Android и Windows на Flutter + FastAPI.

## Что уже есть в проекте
- Backend FastAPI
- Регистрация и вход по username/password
- Хеширование паролей через PBKDF2
- Bearer-токены с истечением срока действия
- Создание диалога и получение списка диалогов
- Отправка и чтение сообщений
- WebSocket endpoint для обновлений в реальном времени
- Flutter-клиент с экранами входа/регистрации и чата

## Важно
Это стартовый прототип, не готовый к публичному запуску продукт. Для продакшена нужны HTTPS, PostgreSQL, rate limiting, проверка безопасности, резервные копии, модерация/жалобы, миграции БД и соблюдение применимых требований к персональным данным. В текущей версии база SQLite для локального запуска, а сообщения сохраняются на сервере без сквозного шифрования.

## 1. Запуск backend (Windows)
Установите Python 3.11+.
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
Документация API: http://127.0.0.1:8000/docs

Для Android-эмулятора используйте `http://10.0.2.2:8000`, а для реального телефона и ПК в одной Wi-Fi сети — локальный IP компьютера, например `http://192.168.1.10:8000`. Не открывайте сервер в интернет без HTTPS и настройки безопасности.

## 2. Запуск Flutter
Установите Flutter SDK и Android Studio (для Android) и/или Visual Studio с workload **Desktop development with C++** (для Windows).
```powershell
cd client
flutter create . --platforms=android,windows
flutter pub get
flutter run -d windows
```
Для Android:
```powershell
flutter run -d android
```
В `lib/main.dart` при необходимости измените `apiBase` на адрес компьютера/сервера. Создание платформенных папок командой `flutter create` может добавить/обновить файлы проекта.

## API
- `POST /auth/register` — `{"username":"user1","password":"...","display_name":"Имя"}`
- `POST /auth/login` — `{"username":"user1","password":"..."}`
- `GET /me`
- `GET /users/search?q=...`
- `POST /chats` — `{"username":"user2"}`
- `GET /chats`
- `GET /chats/{chat_id}/messages`
- `POST /chats/{chat_id}/messages` — `{"text":"Привет!"}`
- `WS /ws?token=...` — события сообщений

## Переменные окружения
- `RUSTALK_SECRET` — обязательно замените перед развёртыванием.
- `RUSTALK_DB` — путь к SQLite-файлу.
