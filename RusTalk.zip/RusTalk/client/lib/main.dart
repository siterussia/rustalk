import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

const String apiBase = 'http://127.0.0.1:8000';

void main() => runApp(const RusTalkApp());

class RusTalkApp extends StatelessWidget {
  const RusTalkApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'RusTalk',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF229ED9)),
      scaffoldBackgroundColor: const Color(0xFFF3F6F9),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF229ED9), foregroundColor: Colors.white),
    ),
    home: const AuthScreen(),
  );
}

class Api {
  static Future<Map<String, dynamic>> auth(String path, String username, String password, {String? name}) async {
    final r = await http.post(Uri.parse('$apiBase$path'),
      headers: {'Content-Type':'application/json'},
      body: jsonEncode({'username': username, 'password': password, if (name != null) 'display_name': name}));
    final body = jsonDecode(r.body);
    if (r.statusCode >= 400) throw Exception(body['detail'] ?? 'Ошибка сервера');
    return body;
  }
  static Future<List<dynamic>> getList(String path, String token) async {
    final r = await http.get(Uri.parse('$apiBase$path'), headers: {'Authorization':'Bearer $token'});
    if (r.statusCode >= 400) throw Exception('Ошибка загрузки');
    return jsonDecode(r.body) as List<dynamic>;
  }
  static Future<Map<String,dynamic>> post(String path, String token, Map<String,dynamic> data) async {
    final r = await http.post(Uri.parse('$apiBase$path'), headers: {
      'Authorization':'Bearer $token','Content-Type':'application/json'
    }, body: jsonEncode(data));
    final body = jsonDecode(r.body);
    if (r.statusCode >= 400) throw Exception(body['detail'] ?? 'Ошибка сервера');
    return body;
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final username = TextEditingController(), password = TextEditingController(), displayName = TextEditingController();
  bool isRegister = true, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() {busy = true; error = null;});
    try {
      final result = await Api.auth(isRegister ? '/auth/register' : '/auth/login',
        username.text.trim(), password.text, name: isRegister ? displayName.text.trim().isEmpty ? username.text.trim() : displayName.text.trim() : null);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) =>
        ChatListScreen(token: result['token'], user: Map<String,dynamic>.from(result['user']))));
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ','')); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420),
      child: Card(elevation: 2, child: Padding(padding: const EdgeInsets.all(24), child: Column(
        mainAxisSize: MainAxisSize.min, children: [
          const CircleAvatar(radius: 34, backgroundColor: Color(0xFF229ED9), child: Icon(Icons.send_rounded, color: Colors.white, size: 34)),
          const SizedBox(height: 16), const Text('RusTalk', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const Text('Общайся без границ', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 24),
          if (isRegister) TextField(controller: displayName, decoration: const InputDecoration(labelText:'Как тебя зовут?', prefixIcon:Icon(Icons.person_outline))),
          TextField(controller: username, decoration: const InputDecoration(labelText:'Имя пользователя', prefixIcon:Icon(Icons.alternate_email))),
          TextField(controller: password, obscureText:true, decoration: const InputDecoration(labelText:'Пароль (минимум 8 символов)', prefixIcon:Icon(Icons.lock_outline))),
          if (error != null) Padding(padding: const EdgeInsets.only(top:12), child: Text(error!, style: const TextStyle(color:Colors.red))),
          const SizedBox(height: 20),
          SizedBox(width:double.infinity, child: FilledButton(onPressed:busy ? null : submit,
            child: Padding(padding: const EdgeInsets.all(12), child: Text(busy ? 'Подождите...' : isRegister ? 'Создать аккаунт' : 'Войти')))),
          TextButton(onPressed:() => setState(() {isRegister = !isRegister; error = null;}),
            child: Text(isRegister ? 'Уже есть аккаунт? Войти' : 'Нет аккаунта? Зарегистрироваться')),
          const SizedBox(height:8),
          const Text('Стартовая версия • Не вводи реальные пароли от других сервисов', textAlign:TextAlign.center, style:TextStyle(fontSize:11,color:Colors.black45))
        ]))))),
  );
}

class ChatListScreen extends StatefulWidget {
  final String token; final Map<String,dynamic> user;
  const ChatListScreen({super.key, required this.token, required this.user});
  @override State<ChatListScreen> createState() => _ChatListScreenState();
}
class _ChatListScreenState extends State<ChatListScreen> {
  List<dynamic> chats = []; bool loading = true; String? error;
  final search = TextEditingController();
  Future<void> load() async {
    try { final result = await Api.getList('/chats', widget.token); if(mounted) setState(() {chats=result;loading=false;error=null;});}
    catch(e) {if(mounted)setState((){loading=false;error=e.toString();});}
  }
  Future<void> newChat() async {
    final name = search.text.trim(); if(name.isEmpty) return;
    try {
      final result = await Api.post('/chats', widget.token, {'username':name});
      if(!mounted)return;
      Navigator.pop(context);
      await load();
      final chat = chats.firstWhere((c) => c['id']==result['id'], orElse:()=>{'id':result['id'],'username':name,'display_name':name});
      if(mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => MessageScreen(token:widget.token, chat:Map<String,dynamic>.from(chat), me:widget.user)));
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString()))); }
  }
  @override void initState(){super.initState();load();}
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('RusTalk'), actions:[IconButton(tooltip:'Новый диалог',icon:const Icon(Icons.edit_square),onPressed:(){
      search.clear(); showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Новый диалог'),
        content:TextField(controller:search,decoration:const InputDecoration(labelText:'Имя пользователя собеседника')),
        actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Отмена')),FilledButton(onPressed:newChat,child:const Text('Открыть'))]));
    })]),
    body: Column(children:[
      Container(color:const Color(0xFF229ED9),padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Row(children:[
        CircleAvatar(backgroundColor:Colors.white,child:Text((widget.user['display_name']??'?').toString().substring(0,1).toUpperCase(),style:const TextStyle(color:Color(0xFF229ED9)))),
        const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(widget.user['display_name']??'Пользователь',style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),
          Text('@${widget.user['username']}',style:const TextStyle(color:Colors.white70))
        ]))
      ])),
      if(error!=null) ListTile(title:Text(error!,style:const TextStyle(color:Colors.red)),trailing:IconButton(onPressed:load,icon:const Icon(Icons.refresh))),
      Expanded(child:loading ? const Center(child:CircularProgressIndicator()) : chats.isEmpty ? const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
        Icon(Icons.chat_bubble_outline,size:52,color:Colors.black26),SizedBox(height:12),Text('Пока нет диалогов'),Text('Нажми на карандаш, чтобы начать чат',style:TextStyle(color:Colors.black54))
      ])) : RefreshIndicator(onRefresh:load,child:ListView.separated(itemCount:chats.length,separatorBuilder:(_,__)=>const Divider(height:1,indent:76),
        itemBuilder:(context,i){final c=Map<String,dynamic>.from(chats[i]);final name=(c['display_name']??c['username']??'Диалог').toString();
          return ListTile(leading:CircleAvatar(backgroundColor:const Color(0xFFD9F0FC),child:Text(name.isEmpty?'?':name[0].toUpperCase(),style:const TextStyle(color:Color(0xFF1679A8)))),
            title:Text(name,style:const TextStyle(fontWeight:FontWeight.w600)),subtitle:Text(c['last_message']??'Начните общение',maxLines:1,overflow:TextOverflow.ellipsis),
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MessageScreen(token:widget.token,chat:c,me:widget.user))).then((_)=>load()));}
      )))
    ]),
  );
}

class MessageScreen extends StatefulWidget {
  final String token; final Map<String,dynamic> chat; final Map<String,dynamic> me;
  const MessageScreen({super.key,required this.token,required this.chat,required this.me});
  @override State<MessageScreen> createState()=>_MessageScreenState();
}
class _MessageScreenState extends State<MessageScreen> {
  final input=TextEditingController(); final scroll=ScrollController();
  List<dynamic> messages=[]; bool loading=true,sending=false; WebSocketChannel? channel; StreamSubscription? subscription;
  int get chatId => widget.chat['id'] as int;
  @override void initState(){super.initState();load();connectWs();}
  Future<void> load() async {
    try {final data=await Api.getList('/chats/$chatId/messages',widget.token);if(mounted)setState(()=>messages=data);}
    catch(_){} finally{if(mounted)setState(()=>loading=false);}
  }
  void connectWs(){
    try {
      final base=Uri.parse(apiBase);
      final uri=Uri(scheme:base.scheme=='https'?'wss':'ws',host:base.host,port:base.port,path:'/ws',queryParameters:{'token':widget.token});
      channel=WebSocketChannel.connect(uri);
      subscription=channel!.stream.listen((raw){try{final event=jsonDecode(raw);if(event['type']=='message' && event['message']['chat_id']==chatId && event['message']['sender_id']!=widget.me['id'] && mounted){setState(()=>messages.add(event['message']));}}catch(_){}},onError:(_){});
    }catch(_){}
  }
  Future<void> send() async {
    final text=input.text.trim();if(text.isEmpty||sending)return;
    setState(()=>sending=true);
    try {final msg=await Api.post('/chats/$chatId/messages',widget.token,{'text':text});
      if(mounted){setState(()=>messages.add(msg));input.clear();}
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}
    finally{if(mounted)setState(()=>sending=false);}
  }
  @override void dispose(){subscription?.cancel();channel?.sink.close();input.dispose();scroll.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final title=(widget.chat['display_name']??widget.chat['username']??'Диалог').toString();
    return Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(fontSize:18)),Text('@${widget.chat['username']??''}',style:const TextStyle(fontSize:12,color:Colors.white70))
    ])),
      body:Column(children:[
        Expanded(child:loading?const Center(child:CircularProgressIndicator()):ListView.builder(reverse:true,padding:const EdgeInsets.all(12),itemCount:messages.length,
          itemBuilder:(context,index){final m=Map<String,dynamic>.from(messages[messages.length-1-index]);final mine=m['sender_id']==widget.me['id'];
            return Align(alignment:mine?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:const BoxConstraints(maxWidth:320),margin:const EdgeInsets.symmetric(vertical:4),
              padding:const EdgeInsets.symmetric(horizontal:14,vertical:10),decoration:BoxDecoration(color:mine?const Color(0xFFD8F4C8):Colors.white,borderRadius:BorderRadius.circular(16)),
              child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
                if(!mine)Align(alignment:Alignment.centerLeft,child:Text('@${m['username']??''}',style:const TextStyle(fontSize:11,color:Color(0xFF1686B8)))),
                Align(alignment:Alignment.centerLeft,child:Text(m['text']??'')),
                Text(DateTime.fromMillisecondsSinceEpoch(((m['created_at']??0) as num).toInt()*1000).toLocal().toString().substring(11,16),style:const TextStyle(fontSize:10,color:Colors.black45))
              ])));
          })),
        SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(8,8,8,8),child:Row(children:[
          Expanded(child:TextField(controller:input,minLines:1,maxLines:5,onSubmitted:(_)=>send(),decoration:InputDecoration(hintText:'Сообщение...',filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(24),borderSide:BorderSide.none),contentPadding:const EdgeInsets.symmetric(horizontal:18,vertical:12)))),
          const SizedBox(width:8),CircleAvatar(backgroundColor:const Color(0xFF229ED9),child:IconButton(onPressed:sending?null:send,icon:const Icon(Icons.send,color:Colors.white)))
        ])))
      ]));
  }
}
